package ApplicationVariables;

/**
 *
 * @author mqul
 */
public enum DataLayerType {
    DATABASE, CSV;
}

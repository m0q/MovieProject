package ClassLayer;

/**
 *
 * @author mqul
 * 
 * Person sub-class - merely passes information
 */
public class Actor extends Person{
    
    public Actor(String actorID, String actorName){
        super (actorID, actorName);
    }
    
}

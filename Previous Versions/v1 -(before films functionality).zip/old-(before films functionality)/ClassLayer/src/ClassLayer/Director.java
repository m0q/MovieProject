package ClassLayer;

/**
 *
 * @author mqul
 * 
 * Person sub-class - merely passes information
 */
public class Director extends Person{
    
    public Director(String directorID, String directorName){
        super (directorID, directorName);
    }
    
}
